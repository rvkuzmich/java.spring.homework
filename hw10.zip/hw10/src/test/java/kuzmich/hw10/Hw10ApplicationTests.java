package kuzmich.hw10;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hw10ApplicationTests {

	@Test
	void contextLoads() {
	}

}
