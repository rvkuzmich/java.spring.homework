package kuzmich.hw8;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hw8Application {

	public static void main(String[] args) {
		SpringApplication.run(Hw8Application.class, args);
	}

}
