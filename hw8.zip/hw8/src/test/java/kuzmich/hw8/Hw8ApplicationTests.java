package kuzmich.hw8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hw8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
